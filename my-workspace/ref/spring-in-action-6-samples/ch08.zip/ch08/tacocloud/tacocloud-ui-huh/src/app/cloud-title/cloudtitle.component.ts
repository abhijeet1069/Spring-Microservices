import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cloud-title',
  templateUrl: 'cloudtitle.component.html',
  styleUrls: ['cloudtitle.component.css']
})

export class CloudTitleComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
