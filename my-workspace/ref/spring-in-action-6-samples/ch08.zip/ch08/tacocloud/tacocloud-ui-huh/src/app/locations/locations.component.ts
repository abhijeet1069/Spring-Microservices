import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'locations-tacocloud',
  templateUrl: 'locations.component.html'
})

export class LocationsComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
